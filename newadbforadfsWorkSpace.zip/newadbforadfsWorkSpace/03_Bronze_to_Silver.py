# Databricks notebook source
# MAGIC %md
# MAGIC Read Bronze Delta

# COMMAND ----------

dbutils.widgets.text("catalog", "")
dbutils.widgets.text("bronzeSchema", "")
dbutils.widgets.text("silverSchema", "")
dbutils.widgets.text("tableName", "")
dbutils.widgets.text("pipelineRunId", "")
dbutils.widgets.text("file", "")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog")
bronzeSchema = dbutils.widgets.get("bronzeSchema")
silverSchema = dbutils.widgets.get("silverSchema")
tableName = dbutils.widgets.get("tableName")
file = dbutils.widgets.get("file")
repo_path = "Hansrajkumhar/adf_E2P/main/datasets"
pipelineRunId = dbutils.widgets.get("pipelineRunId")



print(f"catalog: {catalog}")
print(f"bronzeSchema: {bronzeSchema}")
print(f"silverSchema: {silverSchema}")
print(f"tableName: {tableName}")
print(f"file: {file}")
print(f"pipelineRunId: {pipelineRunId}")

# COMMAND ----------

def schemaValidator(df):

    schema_mapping = {
        field.name: field.dataType.simpleString()
        for field in df.schema.fields
    }

    return schema_mapping

# COMMAND ----------

from pyspark.sql import functions as F

def dataTypeConverter(df, schema_mapping):

    for column, datatype in schema_mapping.items():

        df = df.withColumn(
            column,
            F.col(column).cast(datatype)
        )

    return df

# COMMAND ----------

from pyspark.sql import functions as F

from transformations.column_serializer import ColumnSerializer
from transformations.trim_columns import TrimColumns
from transformations.duplicate_handler import DuplicateHandler
from transformations.null_handler import NullHandler
from transformations.audit_column_transformation import AuditColumnTransformation


bronze_df = spark.table(
    f"{catalog}.{bronzeSchema}.{tableName}"
)


bronze_df = ColumnSerializer(bronze_df).transform()

bronze_df = TrimColumns(bronze_df).transform()

bronze_df, duplicates_removed = DuplicateHandler(bronze_df).transform()
bronze_df, NullsHandled = NullHandler(bronze_df).transform()

schema_mapping = schemaValidator(bronze_df)

bronze_df = dataTypeConverter(
    bronze_df,
    schema_mapping
)

bronze_df = AuditColumnTransformation(
    pipeline_run_id=pipelineRunId,
    source_file=tableName
).transform(bronze_df)


# COMMAND ----------

# MAGIC %md
# MAGIC Data Quality

# COMMAND ----------

(
    bronze_df.write
        .format("delta")
        .mode("overwrite")
        .saveAsTable(
            f"{catalog}.{silverSchema}.{tableName}"
        )
)

# COMMAND ----------

import json
from datetime import datetime

result = {
    "status":'SUCCESS',
    "tablename": tableName,
    "rowsWritten": bronze_df.count(),
    "duplicatesRemoved": duplicates_removed,
    "nullsRemoved": NullsHandled,
    "layer" : silverSchema
}

dbutils.notebook.exit(json.dumps(result))