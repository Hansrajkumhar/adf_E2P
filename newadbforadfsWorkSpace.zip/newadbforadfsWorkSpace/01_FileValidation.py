# Databricks notebook source
dbutils.widgets.text("container", "")
dbutils.widgets.text("folder", "")
dbutils.widgets.text("file", "")
dbutils.widgets.text("layer", "")
dbutils.widgets.text("tableType", "")
dbutils.widgets.text("notebook", "")

# COMMAND ----------

container = dbutils.widgets.get("container")
folder = dbutils.widgets.get("folder")
repo_path = "Hansrajkumhar/adf_E2P/main/datasets"
file = dbutils.widgets.get("file")
layer = dbutils.widgets.get("layer")
tableType = dbutils.widgets.get("tableType")
notebook = dbutils.widgets.get("notebook")

print(container)
print(folder)
print(file)

# COMMAND ----------

storage_account = "adftorage"

file_path = f"abfss://{container}@{storage_account}.dfs.core.windows.net/{repo_path}/{folder}/{file}"

print(file_path)

# COMMAND ----------

df = (
    spark.read
        .option("header", True)
        .option("inferSchema", True)
        .csv(file_path)
)

# COMMAND ----------

# MAGIC %md
# MAGIC Row Count 

# COMMAND ----------

row_count = df.count()
print(row_count)

# COMMAND ----------

# MAGIC %md
# MAGIC Column Count

# COMMAND ----------

column_count = len(df.columns)

print(column_count)

# COMMAND ----------

# MAGIC %md
# MAGIC Schema

# COMMAND ----------

schema = df.schema.json()
print(schema) 

# COMMAND ----------

# MAGIC %md
# MAGIC Schema Hash

# COMMAND ----------

import hashlib

schema_hash = hashlib.sha256(schema.encode()).hexdigest()

print(schema_hash)

# COMMAND ----------

# MAGIC %md
# MAGIC SHA256 of File

# COMMAND ----------

from pyspark.sql.functions import  concat_ws, sha2

df_hash = df.withColumn(
    "row_hash",
    sha2(concat_ws("||", *df.columns), 256)
)

display(df_hash)

# COMMAND ----------

# MAGIC %md
# MAGIC Hash Row by Row

# COMMAND ----------

import hashlib
from pyspark.sql.functions import collect_list

row_hashes_row = (
    df_hash
    .agg(collect_list("row_hash").alias("row_hashes"))
    .collect()[0]
)

row_hashes_list =  row_hashes_row["row_hashes"]
file_hash = hashlib.sha256(
    "".join(sorted(row_hashes_list)).encode("utf-8")
).hexdigest()

print(file_hash)

# COMMAND ----------

import json

result = {
    "fileHash" : file_hash,
    "rowCount" : row_count,
    "columnCount" : column_count,
    "schemaHash" : schema_hash,
    "layer": 'raw',
    "notebook": '01_FileValidation',
    "targetTable": folder,
    "tableType": tableType
}

dbutils.notebook.exit(json.dumps(result))

# COMMAND ----------

