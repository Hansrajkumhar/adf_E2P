# Databricks notebook source
dbutils.widgets.text("folder", "")
dbutils.widgets.text("tableType", "")
dbutils.widgets.text("targetTable", "")
dbutils.widgets.text("pipelineRunId", "")

# COMMAND ----------

folder = dbutils.widgets.get("folder")
tableType = dbutils.widgets.get("tableType")
targetTable = dbutils.widgets.get("targetTable")
pipelineRunId = dbutils.widgets.get("pipelineRunId")

# COMMAND ----------

CATALOG = "dev_catalog"

SILVER_SCHEMA = "silver"

GOLD_SCHEMA = "gold"

# COMMAND ----------

from pyspark.sql import functions as F
import json

silver_df = spark.table(
    f"{CATALOG}.{SILVER_SCHEMA}.{folder}"
)

# COMMAND ----------

from gold_transformations.customer_dimension import CustomerDimension
from gold_transformations.product_dimension import ProductDimension
from gold_transformations.seller_dimension import SellerDimension
from gold_transformations.category_dimension import CategoryDimension
from gold_transformations.geolocation_dimension import GeolocationDimension
from gold_transformations.orders_fact import OrdersFact
from gold_transformations.order_items_fact import OrderItemsFact
from gold_transformations.payments_fact import PaymentFact
from gold_transformations.reviews_fact import ReviewsFact

# COMMAND ----------

TRANSFORMATIONS = {

    # Dimension Tables
    "dim_customer": CustomerDimension,
    "dim_product": ProductDimension,
    "dim_seller": SellerDimension,
    "dim_category": CategoryDimension,
    "dim_geolocation": GeolocationDimension,

    # Fact Tables
    "fact_orders": OrdersFact,
    "fact_order_items": OrderItemsFact,
    "fact_payments": PaymentFact,
    "fact_reviews": ReviewsFact

}

# COMMAND ----------

transformer = TRANSFORMATIONS.get(targetTable)
if transformer is None:
    raise Exception(
        f"No transformation found for '{targetTable}'"
    )

gold_df = transformer(
    silver_df,
    CATALOG,
    SILVER_SCHEMA
).transform()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC **Write Gold Table**

# COMMAND ----------

(
    gold_df.write
        .format("delta")
        .mode("overwrite")
        .saveAsTable(
            f"{CATALOG}.{GOLD_SCHEMA}.{targetTable}"
        )
)

# COMMAND ----------

# MAGIC %md
# MAGIC **Return Audit JSON**

# COMMAND ----------

rows_written = gold_df.count()

result = {
    "status": "SUCCESS",
    "layer": "gold",
    "notebook": "04_Silver_to_Gold",
    "targetTable": targetTable,
    "tableType": tableType,
    "rowsWritten": rows_written,
    "pipelineRunId": pipelineRunId
}

dbutils.notebook.exit(json.dumps(result))

# COMMAND ----------

df = spark.table('dev_catalog.silver.category_translation')
df.columns

# COMMAND ----------

