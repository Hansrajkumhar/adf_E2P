# Databricks notebook source
spark.sql("SHOW CATALOGS").show()

# COMMAND ----------

display(spark.sql("SHOW SCHEMAS IN dev_catalog"))

# COMMAND ----------

display(spark.sql("SHOW EXTERNAL LOCATIONS"))

# COMMAND ----------

display(spark.sql("SHOW STORAGE CREDENTIALS"))

# COMMAND ----------

display(
    dbutils.fs.ls(
        "abfss://rawdata@adftorage.dfs.core.windows.net/"
    )
)

# COMMAND ----------

