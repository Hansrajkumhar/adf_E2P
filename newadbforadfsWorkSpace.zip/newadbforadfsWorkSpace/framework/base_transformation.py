from abc import ABC, abstractmethod

class BaseTransformation(ABC):

    def __init__(self,df):
        self.df = df

    @abstractmethod
    def transform(self):
        pass



