class DuplicateHandler:

    def __init__(self, df):
        self.df = df

    def transform(self):

        before = self.df.count()

        df = self.df.dropDuplicates()

        after = df.count()

        duplicates_removed = before - after

        return df, duplicates_removed