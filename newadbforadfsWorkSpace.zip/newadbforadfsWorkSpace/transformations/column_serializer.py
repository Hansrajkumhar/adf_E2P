# Column Serialization Class
import re

class ColumnSerializer():
    def __init__(self, df):
        self.df = df

    def transform(self):

        renamed_columns = {}

        for col in self.df.columns:

            new_name = (
                col.strip()
                    .lower()
                    .replace(" ", "_")
                    .replace("/", "_")
                    .replace("(", "")
                    .replace(")", "")
                    .replace("'", "")
                    .replace('"', "")
                    .replace(".", "")
                    .replace("-", "_")
                    .replace(":", "")
                    .replace(",", "")
                    .replace(";", "")
            )

            new_name = re.sub(r'[^a-zA-Z0-9_]', '', new_name)

            renamed_columns[col] = new_name
        
        return self.df.withColumnsRenamed(renamed_columns)