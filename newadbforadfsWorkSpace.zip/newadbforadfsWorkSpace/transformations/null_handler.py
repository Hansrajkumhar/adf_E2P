class NullHandler():
    def __init__(self, df):
        self.df = df

    def transform(self):
        before = self.df.count()

        df = self.df.dropna()

        after = df.count()

        NullsHandled = before - after


        return df, NullsHandled