from pyspark.sql import functions as F
class AuditColumnTransformation():

    def __init__(self, pipeline_run_id, source_file):
        self.pipeline_run_id = pipeline_run_id
        self.source_file = source_file

    def transform(self, df):

        return (
            df
            .withColumn("_ingestion_time", F.current_timestamp())
            .withColumn("_pipeline_run_id", F.lit(self.pipeline_run_id))
            .withColumn("_source_file", F.lit(self.source_file))
            .withColumn("_load_date", F.current_date())
            .withColumn(
                "row_hash",
                F.sha2(
                    F.concat_ws(
                        "||",
                        *[F.col(c).cast("string") for c in df.columns]
                    ),
                    256
                )
            )
        )