from pyspark.sql import functions as F

class DataTypeTransformation():

    def __init__(self, schema_mapping):
        self.schema_mapping = schema_mapping

    def transform(self, df):

        for column, datatype in self.schema_mapping.items():

            df = df.withColumn(
                column,
                F.col(column).cast(datatype)
            )

        return df