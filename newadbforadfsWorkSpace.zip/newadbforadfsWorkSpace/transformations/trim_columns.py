
from pyspark.sql.functions import *
from pyspark.sql.types import *

class TrimColumns():
    def __init__(self, df):
        self.df = df

    def transform(self):

        df = self.df

        for field in df.schema.fields:

            if isinstance(field.dataType, StringType):

                df = df.withColumn(
                    field.name,
                    trim(col(field.name))
                )

        return df