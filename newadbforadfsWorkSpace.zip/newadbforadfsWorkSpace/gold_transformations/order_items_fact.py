from gold_transformations.base_GoldTransformation import BaseGoldTransformation
from pyspark.sql import functions as F

class OrderItemsFact(BaseGoldTransformation):

    def transform(self):

        order_items_df = (
            self.df
            .select(
                F.col('order_id'),
                F.col('order_item_id'),
                F.col('product_id'),
                F.col('seller_id'),
                F.to_date('shipping_limit_date').alias('shipping_due_date'),
                F.col('price').alias('item_price'),
                F.col('freight_value').alias('shipping_cost'),
                F.col('_pipeline_run_id')  
            )
            .dropDuplicates(["oder_id", "order_item_id"])
        )

        return orderItems_df




#   def __init__(self, df):
#       super(). __init__(df)

#   def transform(self):
      
#       orderItems_df = (
#           self.df
#           .select(
#             'order_id',
#             'order_item_id',
#             'product_id',
#             'seller_id',
#             'shipping_limit_date',
#             'price',
#             'freight_value',
#             '_pipeline_run_id'
#           )
#           .withColumn(
#               'shipping_limit_date',
#               F.to_date('shipping_limit_date')
#           )
#           .withColumn(
#               "_created_date",
#               F.current_timestamp()
#           )
#           .withColumn(
#               "_pipeline_run_id",
#               F.list(self._pipeline_run_id)
#           )
          
#       )

    #   return orderItems_df
