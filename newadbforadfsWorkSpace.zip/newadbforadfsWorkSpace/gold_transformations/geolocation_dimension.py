from gold_transformations.base_GoldTransformation import BaseGoldTransformation
from pyspark.sql import functions as F

class GeolocationDimension(BaseGoldTransformation):


    def transform(self):

        geolocation_df = (
            self.df
            .select(
                'geolocation_zip_code_prefix',
                'geolocation_lat',
                'geolocation_lng',
                'geolocation_city',
                'geolocation_state'
            )
            .dropDuplicates()
        )

        return geolocation_df