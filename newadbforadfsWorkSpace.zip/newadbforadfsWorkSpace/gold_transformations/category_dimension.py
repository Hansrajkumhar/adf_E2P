from gold_transformations.base_GoldTransformation import BaseGoldTransformation

class CategoryDimension(BaseGoldTransformation):

    def __init__(self, df):
        super().__init__(df)

    def transform(self):

        category_df = (
            self.df
            .select(
                'product_category_name',
                'product_category_name_english'
            )
            .dropDuplicates()
        )
    
        return category_df