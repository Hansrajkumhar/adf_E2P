from gold_transformations.base_GoldTransformation import BaseGoldTransformation

class SellerDimension(BaseGoldTransformation):

    def __init__(self, df):
        super().__init__(df)

    def transform(self):

        seller_df = (
            self.df

            .select(
                'seller_id',
                'seller_zip_code_prefix',
                'seller_city',
                'seller_state'
            )
            .dropDuplicates()
        )
        return seller_df