from gold_transformations.base_GoldTransformation import BaseGoldTransformation
from pyspark.sql import functions as F

class OrdersFact(BaseTransformation):

    customer_dim = spark.table(
        f"{self.catalog}.{self.gold_schema}.dim_customer"
    )

    def transform(self):

        orders_df = (
            self.df.alias("o")
            .join(
                customer_dim.alias("c"),
                on="customer_id",
                how="left"
            )
            .select(
                F.col('order_id'),

                F.col('customer_id'),
                
                F.col('order_status'),
                
                F.col('order_purchase_timestamp').alias("purchase_timestamp"),
                
                F.col('order_approved_at').alias("approval_timestamp"),
                
                F.col('order_delivered_carrier_date').alias("carrier_delivery_timestamp"),
                
                F.col('order_delivered_customer_date').alias("customer_delivery_timestamp"),
                
                F.col('order_estimated_delivery_date').alias("estimated_delivery_timestamp")
            )

            .dropDuplicates(["order_id"])
        )
        

        return orders_df