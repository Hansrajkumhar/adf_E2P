from gold_transformations.base_GoldTransformation import BaseGoldTransformation
from pyspark.sql import functions as F

class ReviewsFact(BaseGoldTransformation):

    def transform(self):

        reviews_df = (
            self.df
            .select(
                F.col('review_id'),
                F.col('order_id'),
                F.col('review_score').alias("customer_rating"),
                F.col('review_comment_title'),
                F.col('review_comment_message'),
                F.to_date('review_creation_date').alias("review_date"),
                F.col('review_answer_timestamp').alias("response_timestamp")
            )
            .dropDuplicates()
        )

        return reviews_df