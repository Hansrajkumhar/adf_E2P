from gold_transformations.base_GoldTransformation import BaseGoldTransformation
from pyspark.sql import functions as F

class ProductDimension(BaseGoldTransformation):

    def transform(self):

        category_df = self.read_silver_table('category_translation')
        

        product_df = (
            self.df.alias("p")
            .join(
                category_df.alias("c"),
                on="product_category_name",
                how="left"
            )
            .select(
                F.col('product_id'),
                F.col('product_category_name'),
                F.col('product_name_lenght'),
                F.col('product_description_lenght'),
                F.col('product_photos_qty'),
                F.col('product_weight_g'),
                F.col('product_length_cm'),
                F.col('product_height_cm'),
                F.col('product_width_cm')
            )
            .dropDuplicates()
        )

        return product_df