from gold_transformations.base_GoldTransformation import BaseGoldTransformation
from pyspark.sql import Window
from pyspark.sql import functions as F


class CustomerDimension(BaseGoldTransformation):


    def transform(self):

        window_spec = Window.orderBY("customer_id")

        customer_df = (
            self.df
            .select(

                "customer_id",
                "customer_unique_id",
                "customer_city",
                "customer_state",
                "customer_zip_code_prefix"
            )

            .dropDuplicates(["customer_id"])
            .withColumn(
                "CustomerKey",
                F.row_number().over(window_spec)
            )
            .select(
                "CustomerKey",
                "customer_id",
                "customer_unique_id",
                "customer_city",
                "customer_state",
                "customer_zip_code_prefix"

            )

        )

        return customer_df