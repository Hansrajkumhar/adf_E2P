from gold_transformations.base_GoldTransformation import BaseGoldTransformation 
from pyspark.sql import functions as F


class PaymentFact(BaseGoldTransformation):

    def transform(self):

        payment_df = (
            self.df
            .select(
                F.col('order_id'),
                F.col('payment_sequential').alias("payment_sequence"),
                F.col('payment_type').alias("payment_mode"),
                F.col('payment_installments').alias("installment_count"),
                F.col('payment_value').alias("payment_amount")
            )
            .dropDuplicates()
        )

        return payment_df