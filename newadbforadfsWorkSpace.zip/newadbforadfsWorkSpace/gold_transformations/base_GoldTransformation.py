from abc import ABC, abstractmethod

class BaseGoldTransformation(ABC):
    def __init__(self, df,catalog, silver_schema):
        self.df = df
        self.catalog = catalog
        self.silver_schema = silver_schema

    def read_silver_table(self, table_name):
        return spark.table(
            f"{self.catalog}.{self.silver_schema}.{table_name}"
        )

    def read_gold_table(self, table_name):
        return spark.table(
            f"{self.catalog}.{self.gold_schema}.{table_name}"
        )

    @abstractmethod
    def transform(self):
        pass

    