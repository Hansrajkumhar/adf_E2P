# Databricks notebook source
dbutils.widgets.text("catalog","dev_catalog")
dbutils.widgets.text("schema", "")
dbutils.widgets.text("container", "")
dbutils.widgets.text("folder", "")
dbutils.widgets.text("file","")
dbutils.widgets.text("PipelineRunId", "")

# COMMAND ----------

storage_account = "adftorage"
catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
container = dbutils.widgets.get("container")
folder = dbutils.widgets.get("folder")
file = dbutils.widgets.get("file")
pipelineRunId = dbutils.widgets.get("PipelineRunId")
repo_path = "Hansrajkumhar/adf_E2P/main/datasets"

print(catalog)
print(schema)
print(container)
print(folder)
print(file)


# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

raw_path = f"abfss://{container}@{storage_account}.dfs.core.windows.net/{repo_path}/{folder}/{file}"

print(raw_path)

# COMMAND ----------

df = (
    spark.read
        .option("header", True)
        .option("inferSchema", True)
        .csv(raw_path)
)

# COMMAND ----------

bronze_df = (
    df
    .withColumn("_ingestion_time", current_timestamp())
    .withColumn("_source_file", lit(file))
    .withColumn("_pipeline_run_id", lit(pipelineRunId))
    .withColumn("_load_date", current_date())
)

# COMMAND ----------

import hashlib

row_count = bronze_df.count()

column_count = len(bronze_df.columns)

schema_hash = hashlib.sha256(
    bronze_df.schema.simpleString().encode("utf-8")
).hexdigest()

# COMMAND ----------

from pyspark.sql.functions import concat_ws, sha2, collect_list
import hashlib

df_hash = bronze_df.withColumn(
    "row_hash",
    sha2(concat_ws("||", *bronze_df.columns), 256)
)

row_hashes = (
    df_hash
    .agg(collect_list("row_hash").alias("row_hashes"))
    .collect()[0]["row_hashes"]
)

file_hash = hashlib.sha256(
    "".join(sorted(row_hashes)).encode("utf-8")
).hexdigest()

# COMMAND ----------

# MAGIC %md
# MAGIC Write to Bronze

# COMMAND ----------

table_name = folder

# COMMAND ----------

(
    bronze_df.write
             .format("delta")
             .mode("overwrite")
             .saveAsTable(f"{catalog}.{schema}.{table_name}")
)

# COMMAND ----------

# display(
#     spark.sql(
#         f"SELECT * FROM `{catalog}.{schema}.{table_name}` LIMIT 10"
#     )
# )

# COMMAND ----------

# import json

# output = {
#     "table": table_name,
#     "fileName": raw_path,
#     "rowsWritten": bronze_df.count(),
#     "status": "Success"
# }

# dbutils.notebook.exit(json.dumps(output))


import json
from datetime import datetime

result = {
    "status": "SUCCESS",
    "table": folder,
    "rowsWritten": row_count,
    "rowCount": row_count,
    "columnCount": column_count,
    "schemaHash": schema_hash,
    "fileHash": file_hash,
    "fileName": file,
    "folderName": folder,
    "pipelineRunId": pipelineRunId,
    "lastModified": datetime.utcnow().isoformat()
}

dbutils.notebook.exit(json.dumps(result))

# COMMAND ----------

